<!-- header styles -->

<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
<style>.u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 793px;
}
.u-header .u-image-1 {
  width: 570px;
  height: 143px;
  margin: 60px auto 0;
}
.u-header .u-line-1 {
  width: 912px;
  height: 3px;
  margin: 10px 60px 0 auto;
}
.u-header .u-image-2 {
  width: 570px;
  height: 570px;
  margin: 17px auto 0;
}
.u-header .u-group-1 {
  width: 570px;
  background-image: none;
  min-height: 228px;
  margin: 30px auto 0;
}
.u-header .u-container-layout-1 {
  padding: 30px;
}
.u-header .u-image-3 {
  width: 253px;
  height: 479px;
  margin: 0 auto;
}
.u-header .u-image-4 {
  width: 570px;
  height: 214px;
  margin: 30px auto 0;
}
.u-header .u-image-5 {
  width: 570px;
  height: 570px;
  margin: 30px auto 0;
}
.u-header .u-image-6 {
  width: 570px;
  height: 526px;
  margin: 30px auto 0;
}
.u-header .u-text-1 {
  margin: 30px 0 60px;
}
.u-header .u-text-2 {
  font-weight: 900;
  width: auto;
  margin: 446px 0 0;
}
.u-header .u-image-7 {
  width: 570px;
  height: 126px;
  margin: 30px 0 60px;
}
@media (max-width: 1199px) {
  .u-header .u-line-1 {
    margin-right: 28px;
  }
  .u-header .u-image-7 {
    margin-left: 0;
    margin-right: 0;
  }
}
@media (max-width: 991px) {
  .u-header .u-line-1 {
    width: 720px;
    margin-right: 0;
  }
}
@media (max-width: 767px) {
  .u-header .u-image-1 {
    width: 540px;
    height: 135px;
  }
  .u-header .u-line-1 {
    width: 540px;
  }
  .u-header .u-image-2 {
    width: 540px;
    height: 540px;
  }
  .u-header .u-group-1 {
    width: 540px;
  }
  .u-header .u-container-layout-1 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-header .u-image-4 {
    width: 540px;
    height: 203px;
  }
  .u-header .u-image-5 {
    width: 540px;
    height: 540px;
  }
  .u-header .u-image-6 {
    width: 540px;
    height: 498px;
  }
  .u-header .u-image-7 {
    width: 540px;
    height: 120px;
  }
}
@media (max-width: 575px) {
  .u-header .u-sheet-1 {
    min-height: 799px;
  }
  .u-header .u-image-1 {
    width: 340px;
    height: 85px;
    margin-top: 47px;
    margin-right: 50px;
    margin-left: -50px;
  }
  .u-header .u-line-1 {
    width: 436px;
    transform-origin: right center 0px;
    margin-top: 36px;
    margin-right: auto;
    margin-left: -46px;
  }
  .u-header .u-image-2 {
    width: 88px;
    height: 88px;
    margin-top: 489px;
  }
  .u-header .u-group-1 {
    width: 159px;
    min-height: 315px;
    margin-top: -555px;
    margin-left: -16px;
  }
  .u-header .u-container-layout-1 {
    padding-bottom: 12px;
  }
  .u-header .u-image-3 {
    height: 291px;
    margin-top: -19px;
    margin-bottom: -2px;
    margin-right: initial;
    margin-left: initial;
    width: auto;
  }
  .u-header .u-image-4 {
    width: 199px;
    height: 65px;
    animation-duration: 1000ms;
    margin-top: -305px;
    margin-right: -8px;
    margin-left: 149px;
  }
  .u-header .u-image-5 {
    width: 104px;
    height: 104px;
    animation-duration: 2000ms;
    margin-top: 0;
    margin-right: 50px;
  }
  .u-header .u-image-6 {
    width: 92px;
    height: 85px;
    margin-top: 6px;
    margin-left: 149px;
  }
  .u-header .u-text-1 {
    width: auto;
    margin: -387px 0 0 auto;
  }
  .u-header .u-image-7 {
    width: 203px;
    height: 46px;
    margin: 126px auto 0;
  }
}</style>
